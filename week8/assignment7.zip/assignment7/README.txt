ASSIGNMENT #7
=============

This is your final assignment! w00t

PART A - Warmup
----------------
Complete the warmup exercise in warmup.js

PART B - Todo List
------------------
Follow the steps in todo.js

