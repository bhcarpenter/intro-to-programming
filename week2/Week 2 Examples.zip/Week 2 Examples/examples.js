(function() { // Ignore this line.

/*
Ignore this function definition. It gives you the "printLine" function that you'll
use through the reset of the assignment. "printLine" is like "print" in the lecture
slides.
*/
function show(string) {
    document.getElementById('output').appendChild(document.createTextNode(string + "\n"));
}


/*
If / Else Example:


var tempInF = prompt("Enter a number in Farenheit:");

tempInF = parseFloat( tempInF );

if ( isNaN(tempInF) ) {
    show("That's not a number!");
    show("Hi!");
    
    var myName = "Brandon";
    show(myName);
    
} else {
	show("Goodbye.");
}
*/



/*
While Loop Example:

var num = Math.random();
while (num < 0.7) {
    show(num.toFixed(2));
    num = Math.random();
}

show("Greater than 0.7: " + num.toFixed(2));
*/



/*
Nested Loop Example:

for (var i = 0; i < 3; i++) {
    for (var j = 0; j < 2; j++) {
        show(i + ", " + j);
    }
}
*/


})(); // Ignore this line.