Homework #2 will be a two part assignment. The goal of the first part is to have better understanding of using objects, so you are able to tackle the second part.

Part 1: Objects Worksheet
Complete the problems in assignment2a.js similar to how you completed assignment1.

Part 2: Working with the DOM
Follow the instructions in assignment2b.js to change the look and feel of assignment2b.html through JavaScript.

