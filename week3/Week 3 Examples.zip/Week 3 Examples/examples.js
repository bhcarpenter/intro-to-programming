/*
Ignore this function definition. It gives you the "show" function that you'll
use through the rest of the assignment.
*/
function show(text) {
    var node = document.createTextNode(text + "\n");
    document.getElementById('output').appendChild(node);
}

/*
function eatSomething(personsName, whatTheyAte) {
	show( personsName + ' ate ' + whatTheyAte );
}

eatSomething( 'Brandon', 'ice cream' );
eatSomething( 'Kaiti', 'meatloaf' );
eatSomething( 'Genevieve', 'cheese' );
*/

function eatSomething(personsName, whatTheyAte) {
	return personsName + ' ate ' + whatTheyAte;
}

var whatBrandonAte = eatSomething( 'Brandon', 'ice cream' );
show(whatBrandonAte);

var kaitisName = 'Kaiti';
var whatKaitiAte = eatSomething( kaitisName, 'meatloaf' );
show(whatKaitiAte);

show( eatSomething( 'Genevieve', 'cheese' ) );




