/*
Ignore this function definition. It gives you the "show" function that you'll
use through the rest of the assignment.
*/
function show(text) {
    var node = document.createTextNode(text + "\n");
    document.getElementById('output').appendChild(node);
}

/*
Problem #1
----------
Use a for loop to print the numbers 1 to 10.
*/
show("------ PROBLEM 1 ------\n");

for (var counter=1; counter <= 10; counter++) {
	show( counter );
}


/*
Problem #2
----------
Print a random integer between 1 and 10 until you hit 4.
*/
show("------ PROBLEM 2 ------\n");

var randomNumber = 0;
while(randomNumber != 4) {
	randomNumber = Math.random();
	randomNumber = Math.floor(randomNumber * 10) + 1;
	show( randomNumber );
}



/*
Problem #3
----------
Ask the user for a number between 2 and 10. use the given number and print a
box on the screen using #.

For example if the user enters 2 you would print:

##
##

If they enter 4 you would print:

####
####
####
####

and so on...

*/
show("------ PROBLEM 3 ------\n");

var num = prompt("Please enter a number between 2 and 10");
num = Number(num);

for (var counter=0; counter < num; counter++) {
	var row = '';
	
	for (var counter2=0; counter2 < num; counter2++) {
		row = row + '#';
	}
	
	show(row);
}


/*
Problem #4
----------
For problem 4 do the same as problem three except make a triangle like the
examples below.

If the user enters 2 you would print:
#
##

If the they enter 4 you would print:
#
##
###
####

*/
show("------ PROBLEM 4 ------\n");

var num = prompt("Please enter a number between 2 and 10");
num = Number(num);

var row = '';
for (var i=0; i < num; i++) {
	row = row + '#';
	show(row);
}

/*
Problem #5
----------
Ask the user for a number less than 20. Print whether or not that number
is prime.

A number is prime if it is not evenly divisible by any numbers betweeen
(but not including) 1 and itself. http://en.wikipedia.org/wiki/Prime_number
*/
show("------ PROBLEM 5 ------\n");

var num = prompt("Please enter a number less than 20");
num = Number(num);

var itIsPrime = true;

for (var i=2; i < num; i++) {
	var remainder = num % i;
	
	if (remainder === 0) {
		itIsPrime = false;
		break;
	}
}

if (itIsPrime) {
	show('It\'s prime.');
} else {
	show('It\'s not prime.');
}



/*
Problem #6
----------
Generate 8 numbers between 1 and 100 at random.

- Print them on one line seperated by commas
- Print the average, max, and min of those numbers
*/
show("------ PROBLEM 6 ------\n");

var row = '';
var max;
var min;
var total = 0;
for (var i=0; i < 8; i++) {
	var randomNumber = Math.floor(Math.random()*100)+1;
	
	// Check to see if we have a new maximum.
	if (i === 0 || randomNumber > max) {
		max = randomNumber;
	}
	
	// Check to see if we have a new minimum.
	if (i === 0 || randomNumber < min) {
		min = randomNumber;
	}
	
	// Increase our total
	total = total + randomNumber;
	
	// Build our row
	if (i === 7) {
		row = row + randomNumber;
	} else {
		row = row + randomNumber + ', ';
	}
}

show(row);
show("Maximum: " + max);
show("Minimum: " + min);
show("Average: " + total/8);





