/*
Ignore these function definitions. They give you the "show" and "diceRoll"
functions that you'll use through the rest of the assignment.
*/
function show(text) {
    var node = document.createTextNode(text + "\n");
    document.getElementById('output').appendChild(node);
}
function diceRoll() {
    return Math.ceil(Math.random() * 6);
}

/*
Make a Dice Game! Here are the rules:
1. Make up a better name for the game.
2. Ask the user how many people are going to play.
3. For each user, "roll a dice" (generate a random number between 1 and 6,
inclusive) until the total of all of the user's rolls is over 21. I've written
a "diceRoll" function for you to use. You can use it like so:
var result = diceRoll(); // result will be a number between 1 and 8.
4. The winner is the person who has the least number of rolls to get over 21.

Here's what your program should output:
- The name of the game.
- The result of each user's dice rolls.
- The winner of the game.
- The average number of rolls among all of the users. The average should be
rounded to two decimal places.

The output should look something like this:

Dice Game!
------------------------------------
1.) 456234
2.) 6646
3.) 213154326
The winner is Player 2!
The average number of rolls is 6.33.
*/

show('No Dice!');
show('------------------------------------');

var numOfPlayers = prompt("How many people are playing?");
numOfPlayers = Number(numOfPlayers);

var currentWinner;
var currentWinnerRolls;
var overallNumberOfRolls = 0;

for (var player=1; player <= numOfPlayers; player++) {

	// Generate random numbers until the player's total > 21.
	var playersTotal = 0;
	var playersNumberOfRolls = 0;
	var randomNumber;
	var row = '';
	
	do {
		randomNumber = diceRoll();
		playersTotal = playersTotal + randomNumber;
		playersNumberOfRolls++;
		overallNumberOfRolls++;
		
		row = row + randomNumber;
	
	} while(playersTotal <= 21);

	// Now we have the number of times it took the player to get over 21.
	if (player === 1 || playersNumberOfRolls < currentWinnerRolls) {
		currentWinner = player;
		currentWinnerRolls = playersNumberOfRolls;
	}
	
	show(player + ': ' + row); // Show the player's rolls

}


var averageNumberOfRolls = overallNumberOfRolls / numOfPlayers;

show("The winner is player " + currentWinner + "!");
show("The average number of rolls is " + averageNumberOfRolls.toFixed(2));















