Homework #2 will be a two part assignment. The goal of the first part is to have better understanding of looping and branching statements, so you are able to tackle the second part.

Part 1: Branching and Looping
Complete the problems in assignment2a.js similar to how you completed assignment1.


Part 2: Dice Game
