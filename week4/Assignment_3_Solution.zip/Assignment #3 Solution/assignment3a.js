/*
Ignore this function definition. It gives you the "show" function that you'll
use through the rest of the assignment.
*/
function show(text) {
    var node = document.createTextNode(text + "\n");
    document.getElementById('output').appendChild(node);
}


/*
NOTE: For the functions you write, it would probably be a good idea to invoke
them a few times with different values to make sure they're working correctly.
*/

/*
Problem #1
----------
Create a function called "canVote" that takes a person's age and returns
true if the person is 18 or older, or false if they are younger than 18.
*/
show("------ PROBLEM 1 ------\n");

function canVote( personsAge ) {
	return personsAge >= 18;
}

var result = canVote( 17 );
show( result );

result = canVote( 21 );
show( result );


/*
Problem #2
----------
Write a function that calculates a tip for a restaurant.

It should take two paramters:
- The amount of the bill
- The percentage to tip

It should return the tip amount.
*/
show("------ PROBLEM 2 ------\n");

/**
 * Please give percentageToTip as a whole number, i.e. 15
 */
function howMuchToTip( amountOfBill, percentageToTip ) {
	percentageToTip = percentageToTip / 100;
	return amountOfBill * percentageToTip;
}

show( howMuchToTip(35, 20) );


/*
Problem #3
----------
Write a function that calculates a tip for a restaurant AND splits the bill
among a group of friends.

It should take three paramaters:
- The amount of the bill
- The percentage to tip
- The number of people splitting the bill

It should return the amount each person should pay.

Instead of copying and pasting the logic from problem #2, I want you to
call the function you wrote in problem #2 as part of your solution.
*/
show("------ PROBLEM 3 ------\n");


function howMuchEachPersonShouldPay( amountOfBill, percentageToTip, numberOfPeople) {
	var tipAmount = howMuchToTip(amountOfBill, percentageToTip);
	var totalBill = amountOfBill + tipAmount;
	return totalBill / numberOfPeople;
}

show( howMuchEachPersonShouldPay(35, 20, 2) );


/*
Problem #4
----------
Write an email signature function that takes in:
- name
- title
- company
- email address
- phone number

and prints something that looks like an email signature. You won't need to
return any values, just make calls to show() directly in your email signature
function.

Please be creative!
*/
show("------ PROBLEM 4 ------\n");

var emailSignature = function(name, title, company, emailAddress, phoneNumber) {
	show('------------------------');
	show('|' + name + '                |');
	show('------------------------');
	show(title + ' -> ' + company);
	show('e: ' + emailAddress);
	show('tel: ' + phoneNumber);
	show("\n");
}

emailSignature('Brandon', 'Software Engineer', 'Scoutmob', 'brandon@scoutmob.com', '555-555-5555');

/*
Problem #5
----------
Create a "me" object that represents your contact information. It should have
the following properties:
- name
- title
- company
- emailAddress
- phoneNumber

Print out the "me" object's name.

Note: You don't need to write any functions to do this problem. The only
function you'll use is the show() function (to print the object's name).
*/
show("------ PROBLEM 5 ------\n");

var me = {
	name: 'Brandon',
	title: 'Software Engineer',
	company: 'Scoutmob',
	emailAddress: 'brandon@scoutmob.com',
	phoneNumber: '555-555-5555'
};

show( me.name );


/*
Problem #6
----------
Update your email signature function so that instead of taking in 5 different
values, it only takes in 1 value which will be an object with the same
properties as the "me" object from Problem #5.

Call your new email function with the "me" object you made in Problem #5. The
output should look exactly the same as the output from Problem #4.
*/
show("------ PROBLEM 6 ------\n");

var emailSignature2 = function(options) {
	show('------------------------');
	show('|' + options.name + '                |');
	show('------------------------');
	show(options.title + ' -> ' + options.company);
	show('e: ' + options.emailAddress);
	show('tel: ' + options.phoneNumber);
	show("\n");
}

emailSignature2( me );

/* ******************************
 * Everything below is just as an example
 * ****************************** */

var kaiti = {
	name: 'Kaiti',
	title: 'Mom Spectacular',
	company: '',
	emailAddress: 'email@email.com',
	phoneNumber: '555-555-5556'
};
emailSignature2( kaiti );

// The second example above is equivalent to the below, since variables
// and their values are equivalent.

emailSignature2( {
	name: 'Kaiti',
	title: 'Mom Spectacular',
	company: '',
	emailAddress: 'email@email.com',
	phoneNumber: '555-555-5556'
} );