/* Part B
 *
 * Check the HTML file for problem descriptions.
 */
$(document).ready(function() {

  // Any code you write that attaches event handlers to DOM elements needs
  // to go in this function. jQuery waits to execute this function until after
  // the DOM is available to mess with.


});

