/* Part 1: Tip Calculator
 * For this assignment you're going to build a website "frontend" for the tip
 * calculator that you wrote in Assignment #3. If your tip calculator/splitter
 * from Assignment #3 doesn't work, you may use the posted solution instead.
 *
 * Here's what I want you to do:
 * 1. Add an event listener to the "submit" event of the tipCalculator form on
 *    the page.
 * 2. In your event listener:
 *    - Call the preventDefault() method of the event object so that the form
 *      doesn't reload the web page.
 *    - Get the value of the billAmount text field
 *    - Get the value of the percentageToTip text field
 *    - Get the value of the numberOfPeople text field
 *    - Convert all the values into number, and run them through your tip
 *      calculator/splitter
 *    - Display the result in the amountEachPersonShouldPay <div>
 * 3. Make the page look better. Feel free to edit the CSS and HTML.
 *
 * You may not use jQuery for this part. Here are the DOM functions that I
 * think you may need:
 *
 * document.addEventListener()
 * document.getElementById()
 * document.createTextNode()
 * someElement.appendChild()
 * someEvent.preventDefault()
 *
 * Note: The current value entered by a user into a text field is available as
 * the "value" property of the corresponding DOM element.
 */

function howMuchToTip( amountOfBill, percentageToTip ) {
	percentageToTip = percentageToTip / 100;
	return amountOfBill * percentageToTip;
}

function howMuchEachPersonShouldPay( amountOfBill, percentageToTip, numberOfPeople) {
	var tipAmount = howMuchToTip(amountOfBill, percentageToTip);
	var totalBill = amountOfBill + tipAmount;
	return totalBill / numberOfPeople;
}


document.addEventListener('DOMContentLoaded', function(contentLoadedEvent) {

    // Put all of your code that attaches event handlers to DOM elements inside
    // of this function. It will be executed when the DOM is ready
    // to be messed with.
    // Note: This doesn't work in old versions of IE, so test your homework in
    // Firefox, Safari, or Chrome.

	
	var handleSubmitEvent = function(e) {
		e.preventDefault();
		
		var billAmountEl = document.getElementById('billAmount');
		var percentageToTipEl = document.getElementById('percentageToTip');
		var numberOfPeopleEl = document.getElementById('numberOfPeople');
		var outputEl = document.getElementById('amountEachPersonShouldPay');
		
		var billAmountValue = billAmountEl.value;
		var percentageToTipValue = percentageToTipEl.value;
		var numberOfPeopleValue = numberOfPeopleEl.value;
		
		billAmountValue = parseFloat(billAmountValue);
		percentageToTipValue = Number(percentageToTipValue);
		numberOfPeopleValue = parseInt(numberOfPeopleValue, 10);
		
		var eachPersonShouldPay = howMuchEachPersonShouldPay(
			billAmountValue,
			percentageToTipValue, 
			numberOfPeopleValue
		);
		
		// Write it out onto the page
		var newOutputText = document.createTextNode( eachPersonShouldPay );
		outputEl.appendChild(newOutputText);
	};
	
	var formEl = document.getElementById('tipCalculator');
	formEl.addEventListener('submit', handleSubmitEvent);

});












