/* Part B
 *
 * Check the HTML file for problem descriptions.
 */
$(document).ready(function() {

	// Any code you write that attaches event handlers to DOM elements needs
	// to go in this function. jQuery waits to execute this function until after
	// the DOM is available to mess with.

	// PROBLEM #1
	jQuery('#problem1Form').bind('submit', function(event) {
		var field = jQuery('#problem1Field');
		var value = field.val();
		alert(value);
	});
	
	
	// PROBLEM #2
	var ul = $('#problem2List');
	for (var i=1; i <= 15; i++) {
		var html = '<li>' + i + '</li>';
		ul.append(html);
	}
	
	// PROBLEM #3
	var link = $('#problem3Link');
	link.bind('click', function(event) {
		event.preventDefault();
		var allLIs = $('#problem2List li');
		allLIs.css('background', '#00ff00');
	});
	
	// PROBLEM #4
	$('#problem4Image').bind('mouseover', function(e) {
		$('#problem4Image').attr('src', 'image2.png');
	});


});

