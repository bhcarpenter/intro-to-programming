/* Part A
 *
 * Check the HTML file for problem descriptions.
 */


