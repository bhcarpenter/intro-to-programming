Built-In Types Warmup
=====================
Complete the warmup exercise in warmup.js

